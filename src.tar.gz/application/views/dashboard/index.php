<?php $this->load->view('includes/navbar'); ?>

<div class="container" id="main">

    <h1>Home page</h1>

</div>




